 <div class="topnav">
  <a href="Index.php">Home</a>
  <a href="Play.php">Player</a>
  <a href="#">Search</a>
  <a href="#">Login</a>
</div>